import { useState, useRef, useCallback, useEffect, useMemo } from 'react';
import {
  OutageEvent, Oscillogram, EMPTY_EVENT, COLUMNS, VOLTAGE_OPTIONS,
  isIncomplete, parseDateStr, nowDateStr,
} from './types';
import { parseWorkbook, exportToExcel, ImportColumn, ParsedSheet } from './excelUtils';
import {
  Plus, Upload, Download, Save, LogOut, Trash2, Filter, X, FileText, AlertTriangle,
} from 'lucide-react';

const STORAGE_KEY = 'outage_program_events_v1';

function loadEvents(): OutageEvent[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return JSON.parse(raw);
  } catch { /* ignore */ }
  return [];
}

type QuickFilter = 'none' | 'refusal' | 'v330' | 'v110' | 'incomplete';

const QUICK_FILTERS: { id: QuickFilter; label: string }[] = [
  { id: 'refusal', label: 'Отключения с отказом' },
  { id: 'v330', label: 'Отключения по сети 330 кВ' },
  { id: 'v110', label: 'Отключения по сети 110 кВ' },
  { id: 'incomplete', label: 'Не оформленные отключения' },
];

// ---------- Модальное окно подтверждения ----------
function ConfirmModal({
  title, buttons, onClose,
}: { title: string; buttons: { label: string; onClick: () => void; danger?: boolean }[]; onClose: () => void }) {
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50" onClick={onClose}>
      <div className="bg-white rounded-lg shadow-xl p-6 max-w-md w-full mx-4" onClick={(e) => e.stopPropagation()}>
        <div className="text-lg font-semibold mb-4">{title}</div>
        <div className="flex flex-wrap gap-2 justify-end">
          {buttons.map((b) => (
            <button key={b.label} onClick={b.onClick}
              className={`px-4 py-2 rounded font-medium transition-colors ${
                b.danger ? 'bg-red-600 text-white hover:bg-red-700' : 'bg-slate-200 hover:bg-slate-300'
              }`}>
              {b.label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

// ---------- Форма события ----------
function EventForm({
  initial, onSave, onClose,
}: { initial: OutageEvent | null; onSave: (e: OutageEvent) => void; onClose: () => void }) {
  const [ev, setEv] = useState<OutageEvent>(initial ?? { ...EMPTY_EVENT, id: crypto.randomUUID(), oscillograms: [] });
  const oscInputRef = useRef<HTMLInputElement>(null);

  const set = (k: keyof OutageEvent, v: any) => setEv((p) => ({ ...p, [k]: v }));

  const addOscFiles = (files: FileList | null) => {
    if (!files) return;
    Array.from(files).forEach((f) => {
      const reader = new FileReader();
      reader.onload = () => {
        setEv((p) => ({
          ...p,
          oscillograms: [...p.oscillograms, { id: crypto.randomUUID(), name: f.name, dataUrl: reader.result as string, type: f.type }],
        }));
      };
      reader.readAsDataURL(f);
    });
  };

  const field = (label: string, key: keyof OutageEvent, placeholder = '') => (
    <label className="block">
      <span className="text-xs font-semibold text-slate-600">{label}</span>
      <input
        className="mt-1 w-full border border-slate-300 rounded px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
        value={(ev as any)[key] ?? ''}
        onChange={(e) => set(key, e.target.value)}
        placeholder={placeholder}
      />
    </label>
  );

  return (
    <div className="fixed inset-0 bg-black/50 flex items-start justify-center z-50 overflow-y-auto py-8" onClick={onClose}>
      <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-3xl mx-4" onClick={(e) => e.stopPropagation()}>
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-bold">{initial ? 'Редактирование события' : 'Новое событие'}</h2>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-700"><X size={20} /></button>
        </div>
        <p className="text-xs text-slate-500 mb-4">Все поля необязательны — информацию можно дополнить позже.</p>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {field('Дата отключения (дд.мм.гггг чч:мм)', 'date', nowDateStr())}
          {field('Линия ("ПС №1" - "ПС №2")', 'line', 'ПС 110 кВ "Заря" - ПС 110 кВ "Искра"')}
          <label className="block">
            <span className="text-xs font-semibold text-slate-600">Класс напряжения, кВ</span>
            <select
              className="mt-1 w-full border border-slate-300 rounded px-2 py-1.5 text-sm bg-white"
              value={ev.voltage}
              onChange={(e) => set('voltage', e.target.value)}
            >
              <option value="">— не указан —</option>
              {VOLTAGE_OPTIONS.map((v) => <option key={v} value={v}>{v} кВ</option>)}
              <option value="other">Другое</option>
            </select>
          </label>
          {(ev.voltage === 'other' || (ev.voltage && !VOLTAGE_OPTIONS.includes(ev.voltage))) &&
            field('Напряжение, кВ (уточнение)', 'voltage')}
          {field('Работа РЗА на ПС №1', 'rzaPs1', 'ДЗЛ, АПВ У')}
          {field('Работа РЗА на ПС №2', 'rzaPs2', 'ДЗЛ, АПВ НУ')}
          {field('Причина повреждения', 'cause', 'Обрыв провода в пролёте')}
          {field('ОМП расчетное (РАС/ФИП/МП терминалы + модель)', 'ompCalc', 'РАС Парма, 12,4 км от ПС №1')}
          {field('ОМП реальное (привязка к ПС)', 'ompReal', '12,1 км от ПС №1')}
          {field('Анализ работы (П-2, У/НУ)', 'analysis', 'П-2, АПВ У')}
          {field('Работа РЗА на смежных ПС', 'rzaAdjacent', 'Без замечаний')}
          <label className="block sm:col-span-2">
            <span className="text-xs font-semibold text-slate-600">Примечания</span>
            <textarea
              className="mt-1 w-full border border-slate-300 rounded px-2 py-1.5 text-sm min-h-[60px]"
              value={ev.notes}
              onChange={(e) => set('notes', e.target.value)}
            />
          </label>
        </div>

        <label className="flex items-center gap-2 mt-3 select-none cursor-pointer">
          <input type="checkbox" checked={ev.refusal} onChange={(e) => set('refusal', e.target.checked)}
            className="w-4 h-4 accent-red-600" />
          <span className="text-sm font-semibold text-red-700">Отказ</span>
          <span className="text-xs text-slate-500">(событие будет помечено красным)</span>
        </label>

        <div className="mt-4 border-t pt-3">
          <div className="text-xs font-semibold text-slate-600 mb-2">Осциллограммы</div>
          <input ref={oscInputRef} type="file" multiple accept="image/*,.pdf" className="hidden"
            onChange={(e) => { addOscFiles(e.target.files); e.target.value = ''; }} />
          <button type="button" onClick={() => oscInputRef.current?.click()}
            className="text-sm px-3 py-1.5 bg-slate-100 hover:bg-slate-200 rounded border">
            Прикрепить файлы…
          </button>
          {ev.oscillograms.length > 0 && (
            <ul className="mt-2 space-y-1">
              {ev.oscillograms.map((o) => (
                <li key={o.id} className="flex items-center gap-2 text-sm">
                  <FileText size={14} className="text-slate-400 shrink-0" />
                  <span className="truncate">{o.name}</span>
                  <button type="button" className="text-red-500 hover:text-red-700 ml-auto"
                    onClick={() => setEv((p) => ({ ...p, oscillograms: p.oscillograms.filter((x) => x.id !== o.id) }))}>
                    <Trash2 size={14} />
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>

        <div className="flex justify-end gap-2 mt-5">
          <button onClick={onClose} className="px-4 py-2 rounded bg-slate-200 hover:bg-slate-300 text-sm font-medium">Отмена</button>
          <button onClick={() => onSave(ev)} className="px-4 py-2 rounded bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium">Сохранить событие</button>
        </div>
      </div>
    </div>
  );
}

// ---------- Импорт из Excel ----------
function ImportModal({
  sheets, onConfirm, onClose,
}: { sheets: ParsedSheet[]; onConfirm: (eventsBySheet: Map<string, OutageEvent[]>) => void; onClose: () => void }) {
  // состояние выбора столбцов по листам
  const [colsState, setColsState] = useState<Map<string, ImportColumn[]>>(
    () => new Map(sheets.map((s) => [s.sheetName, s.columns.map((c) => ({ ...c }))]))
  );
  const [activeSheet, setActiveSheet] = useState(sheets[0]?.sheetName ?? '');

  const sortedSheets = useMemo(
    () => [...sheets].sort((a, b) => (a.year ?? 9999) - (b.year ?? 9999)),
    [sheets]
  );

  const toggleCol = (sheet: string, idx: number, include: boolean) => {
    setColsState((prev) => {
      const m = new Map(prev);
      const cols = (m.get(sheet) ?? []).map((c, i) => (i === idx ? { ...c, include } : c));
      m.set(sheet, cols);
      return m;
    });
  };

  const doImport = () => {
    const result = new Map<string, OutageEvent[]>();
    for (const s of sortedSheets) {
      const cols = colsState.get(s.sheetName) ?? s.columns;
      // пересобираем события с учётом выбранных столбцов
      const events: OutageEvent[] = [];
      for (const ev of s.rows[0]) {
        const clone: OutageEvent = { ...EMPTY_EVENT, id: ev.id, oscillograms: [] };
        let hasData = false;
        cols.forEach((c) => {
          if (!c.include || !c.targetKey || c.targetKey === 'oscillograms') return;
          const val = (ev as any)[c.targetKey];
          if (val === '' || val == null || (c.targetKey === 'refusal' && val === false)) return;
          (clone as any)[c.targetKey] = val;
          hasData = true;
        });
        if (hasData) events.push(clone);
      }
      result.set(s.sheetName, events);
    }
    onConfirm(result);
  };

  const active = sortedSheets.find((s) => s.sheetName === activeSheet) ?? sortedSheets[0];
  const activeCols = active ? colsState.get(active.sheetName) ?? active.columns : [];
  const totalNew = sortedSheets.reduce((acc, s) => acc + (s.rows[0]?.length ?? 0), 0);

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50" onClick={onClose}>
      <div className="bg-white rounded-lg shadow-xl p-6 max-w-2xl w-full mx-4 max-h-[85vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}>
        <div className="flex justify-between items-center mb-3">
          <h2 className="text-lg font-bold">Импорт событий из Excel</h2>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-700"><X size={20} /></button>
        </div>
        <p className="text-sm text-slate-600 mb-3">
          Найдено листов (годов): <b>{sortedSheets.length}</b>, событий для импорта: <b>{totalNew}</b>.
          События будут отсортированы по годам. Отметьте столбцы, которые нужно импортировать.
          Столбцы «Аварийные параметры на ПС №1/№2» удалены из формы с 2020 г. и по умолчанию не импортируются.
        </p>

        <div className="flex flex-wrap gap-1 mb-3">
          {sortedSheets.map((s) => (
            <button key={s.sheetName} onClick={() => setActiveSheet(s.sheetName)}
              className={`px-3 py-1.5 rounded text-sm font-medium border ${
                activeSheet === s.sheetName ? 'bg-blue-600 text-white border-blue-600' : 'bg-white hover:bg-slate-100'
              }`}>
              {s.year ? `${s.year}` : s.sheetName}
            </button>
          ))}
        </div>

        {active && (
          <div className="border rounded-md">
            <div className="bg-slate-50 px-3 py-2 text-sm font-semibold border-b">
              Лист «{active.sheetName}» {active.year ? `(${active.year} г.)` : ''} — {active.rows[0]?.length ?? 0} событий
            </div>
            <div className="max-h-64 overflow-y-auto divide-y">
              {activeCols.map((c, i) => (
                <label key={i} className="flex items-center gap-2 px-3 py-1.5 text-sm hover:bg-slate-50 cursor-pointer">
                  <input type="checkbox" checked={c.include} disabled={!c.targetKey}
                    onChange={(e) => toggleCol(active.sheetName, i, e.target.checked)}
                    className="w-4 h-4 accent-blue-600" />
                  <span className={c.targetKey ? '' : 'text-slate-400'}>{c.excelHeader}</span>
                  {!c.targetKey && (
                    <span className="ml-auto text-xs px-2 py-0.5 rounded bg-amber-100 text-amber-800">
                      не импортируется (нет в новой форме)
                    </span>
                  )}
                  {c.targetKey && (
                    <span className="ml-auto text-xs text-slate-400">
                      → {COLUMNS.find((col) => col.key === c.targetKey)?.title ?? (c.targetKey === 'refusal' ? 'Отказ' : '')}
                    </span>
                  )}
                </label>
              ))}
            </div>
          </div>
        )}

        <div className="flex justify-end gap-2 mt-4">
          <button onClick={onClose} className="px-4 py-2 rounded bg-slate-200 hover:bg-slate-300 text-sm font-medium">Отмена</button>
          <button onClick={doImport} className="px-4 py-2 rounded bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium">
            Импортировать
          </button>
        </div>
      </div>
    </div>
  );
}

// ---------- Фильтр по значению столбца ----------
function ColumnFilterPopover({
  colKey, title, events, selected, onApply, onClose,
}: {
  colKey: keyof OutageEvent; title: string; events: OutageEvent[];
  selected: Set<string>; onApply: (vals: Set<string>) => void; onClose: () => void;
}) {
  const values = useMemo(() => {
    const set = new Set<string>();
    events.forEach((e) => {
      const v = String((e as any)[colKey] ?? '').trim();
      if (v) set.add(v);
    });
    return [...set].sort((a, b) => a.localeCompare(b, 'ru'));
  }, [events, colKey]);
  const [checked, setChecked] = useState<Set<string>>(new Set(selected));
  const [search, setSearch] = useState('');

  const shown = values.filter((v) => v.toLowerCase().includes(search.toLowerCase()));

  return (
    <>
      <div className="fixed inset-0 z-40" onClick={onClose} />
      <div className="absolute top-full left-0 mt-1 z-50 bg-white border border-slate-300 rounded-md shadow-lg w-64 p-2">
        <div className="text-xs font-semibold text-slate-600 mb-1">{title}</div>
        <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Поиск…"
          className="w-full text-sm border border-slate-300 rounded px-2 py-1 mb-1" />
        <div className="max-h-48 overflow-y-auto">
          {shown.length === 0 && <div className="text-xs text-slate-400 px-1 py-2">Нет значений</div>}
          {shown.map((v) => (
            <label key={v} className="flex items-start gap-2 text-sm px-1 py-0.5 cursor-pointer hover:bg-slate-50">
              <input type="checkbox" className="mt-1 accent-blue-600" checked={checked.has(v)}
                onChange={(e) => {
                  setChecked((p) => { const n = new Set(p); e.target.checked ? n.add(v) : n.delete(v); return n; });
                }} />
              <span className="break-all">{v}</span>
            </label>
          ))}
        </div>
        <div className="flex justify-between mt-2">
          <button className="text-xs text-blue-600 hover:underline" onClick={() => setChecked(new Set())}>Сбросить</button>
          <button className="text-xs px-2 py-1 bg-blue-600 text-white rounded hover:bg-blue-700"
            onClick={() => onApply(checked)}>OK</button>
        </div>
      </div>
    </>
  );
}

// ---------- Основная таблица / приложение ----------
export default function App() {
  const [events, setEvents] = useState<OutageEvent[]>(loadEvents);
  const [savedSnapshot, setSavedSnapshot] = useState<string>(() => JSON.stringify(loadEvents()));
  const [editing, setEditing] = useState<OutageEvent | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [quickFilter, setQuickFilter] = useState<QuickFilter>('none');
  const [colFilters, setColFilters] = useState<Map<keyof OutageEvent, Set<string>>>(new Map());
  const [openFilterCol, setOpenFilterCol] = useState<keyof OutageEvent | null>(null);
  const [confirmClear, setConfirmClear] = useState(false);
  const [confirmExit, setConfirmExit] = useState(false);
  const [importSheets, setImportSheets] = useState<ParsedSheet[] | null>(null);
  const [hoveredOsc, setHoveredOsc] = useState<{ evId: string; x: number; y: number } | null>(null);
  const [lightbox, setLightbox] = useState<Oscillogram | null>(null);
  const [toast, setToast] = useState<string>('');
  const importInputRef = useRef<HTMLInputElement>(null);

  const dirty = JSON.stringify(events) !== savedSnapshot;

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(''), 2500);
  };

  const save = useCallback(() => {
    const snap = JSON.stringify(events);
    try {
      localStorage.setItem(STORAGE_KEY, snap);
      setSavedSnapshot(snap);
      showToast('Данные сохранены');
    } catch (e) {
      showToast('Ошибка сохранения (возможно, превышен лимит хранилища из-за осциллограмм)');
    }
  }, [events]);

  // предупреждение при закрытии вкладки, если есть несохраненные изменения
  useEffect(() => {
    const handler = (e: BeforeUnloadEvent) => {
      if (dirty) { e.preventDefault(); e.returnValue = ''; }
    };
    window.addEventListener('beforeunload', handler);
    return () => window.removeEventListener('beforeunload', handler);
  }, [dirty]);

  const filtered = useMemo(() => {
    let list = events;
    if (quickFilter === 'refusal') list = list.filter((e) => e.refusal);
    else if (quickFilter === 'v330') list = list.filter((e) => e.voltage === '330');
    else if (quickFilter === 'v110') list = list.filter((e) => e.voltage === '110');
    else if (quickFilter === 'incomplete') list = list.filter((e) => isIncomplete(e));

    for (const [key, vals] of colFilters) {
      if (vals.size === 0) continue;
      list = list.filter((e) => {
        const v = String((e as any)[key] ?? '').trim();
        return vals.has(v);
      });
    }
    return [...list].sort((a, b) => (parseDateStr(a.date)?.getTime() ?? 0) - (parseDateStr(b.date)?.getTime() ?? 0));
  }, [events, quickFilter, colFilters]);

  const handleSaveEvent = (ev: OutageEvent) => {
    setEvents((prev) => {
      const idx = prev.findIndex((e) => e.id === ev.id);
      if (idx >= 0) { const n = [...prev]; n[idx] = ev; return n; }
      return [...prev, ev];
    });
    setShowForm(false);
    setEditing(null);
  };

  const deleteEvent = (id: string) => {
    setEvents((prev) => prev.filter((e) => e.id !== id));
  };

  const handleImportFile = async (file: File) => {
    const buf = await file.arrayBuffer();
    try {
      const sheets = parseWorkbook(buf);
      if (!sheets.length) { showToast('В файле не найдено листов с данными'); return; }
      setImportSheets(sheets);
    } catch (e) {
      showToast('Не удалось прочитать файл Excel');
    }
  };

  const confirmImport = (bySheet: Map<string, OutageEvent[]>) => {
    const incoming: OutageEvent[] = [];
    bySheet.forEach((list) => incoming.push(...list));
    setEvents((prev) => [...prev, ...incoming]);
    setImportSheets(null);
    showToast(`Импортировано событий: ${incoming.length}`);
  };

  const exitWithoutSave = () => {
    try {
      const restored = JSON.parse(savedSnapshot);
      setEvents(restored);
    } catch { /* ignore */ }
    window.close();
    // если браузер запретил close — покажем подсказку
    showToast('Закройте вкладку вручную (браузер блокирует автоматическое закрытие)');
  };

  const hoveredEvent = hoveredOsc ? events.find((e) => e.id === hoveredOsc.evId) : null;

  const btnCls = 'inline-flex items-center gap-1.5 px-3 py-2 rounded-md text-sm font-medium transition-colors shadow-sm';

  return (
    <div className="min-h-screen bg-slate-100 text-slate-800">
      <header className="bg-slate-800 text-white px-4 py-3 shadow sticky top-0 z-30">
        <div className="flex flex-wrap items-center gap-3 max-w-[1800px] mx-auto">
          <h1 className="text-lg font-bold mr-auto">Программа отключений <span className="font-normal text-slate-300 text-sm">— сеть 110 / 330 кВ</span></h1>
          <div className="flex flex-wrap gap-2">
            <button className={`${btnCls} bg-green-600 hover:bg-green-700 text-white`} onClick={() => { setEditing(null); setShowForm(true); }}>
              <Plus size={16} /> Добавить событие
            </button>
            <button className={`${btnCls} bg-blue-600 hover:bg-blue-700 text-white`} onClick={() => importInputRef.current?.click()}>
              <Upload size={16} /> Импорт событий
            </button>
            <input ref={importInputRef} type="file" accept=".xlsx,.xls,.csv" className="hidden"
              onChange={(e) => { const f = e.target.files?.[0]; if (f) handleImportFile(f); e.target.value = ''; }} />
            <button className={`${btnCls} bg-blue-600 hover:bg-blue-700 text-white`} onClick={() => exportToExcel(filtered.length ? filtered : events)}>
              <Download size={16} /> Экспорт событий
            </button>
            <button className={`${btnCls} ${dirty ? 'bg-amber-500 hover:bg-amber-600 text-white' : 'bg-slate-500 text-slate-200'}`} onClick={save}>
              <Save size={16} /> Сохранить {dirty && <span className="w-2 h-2 rounded-full bg-white inline-block" />}
            </button>
            <button className={`${btnCls} bg-red-600 hover:bg-red-700 text-white`} onClick={() => setConfirmClear(true)}>
              <Trash2 size={16} /> Очистить таблицу
            </button>
            <button className={`${btnCls} bg-slate-600 hover:bg-slate-500 text-white`} onClick={() => setConfirmExit(true)}>
              <LogOut size={16} /> Выйти
            </button>
          </div>
        </div>
      </header>

      {/* Быстрые фильтры */}
      <div className="max-w-[1800px] mx-auto px-4 pt-3 flex flex-wrap items-center gap-2">
        <Filter size={16} className="text-slate-500" />
        <span className="text-sm text-slate-600 font-medium">Быстрые фильтры:</span>
        <button onClick={() => setQuickFilter('none')}
          className={`px-3 py-1 rounded-full text-sm border ${quickFilter === 'none' ? 'bg-slate-800 text-white border-slate-800' : 'bg-white hover:bg-slate-50'}`}>
          Все ({events.length})
        </button>
        {QUICK_FILTERS.map((f) => {
          const count = (() => {
            if (f.id === 'refusal') return events.filter((e) => e.refusal).length;
            if (f.id === 'v330') return events.filter((e) => e.voltage === '330').length;
            if (f.id === 'v110') return events.filter((e) => e.voltage === '110').length;
            return events.filter((e) => isIncomplete(e)).length;
          })();
          const activeQ = quickFilter === f.id;
          return (
            <button key={f.id} onClick={() => setQuickFilter(activeQ ? 'none' : f.id)}
              className={`px-3 py-1 rounded-full text-sm border ${
                activeQ ? (f.id === 'refusal' ? 'bg-red-600 text-white border-red-600' : 'bg-blue-600 text-white border-blue-600')
                : 'bg-white hover:bg-slate-50'
              }`}>
              {f.label} ({count})
            </button>
          );
        })}
        {colFilters.size > 0 && (
          <button className="text-sm text-blue-700 underline ml-2"
            onClick={() => { setColFilters(new Map()); }}>
            Сбросить фильтры столбцов
          </button>
        )}
      </div>

      {/* Таблица */}
      <main className="max-w-[1800px] mx-auto p-4">
        <div className="bg-white rounded-lg shadow overflow-auto border" style={{ maxHeight: 'calc(100vh - 190px)' }}>
          <table className="border-collapse text-sm w-full" style={{ minWidth: 1700 }}>
            <thead className="sticky top-0 z-20">
              <tr className="bg-slate-700 text-white">
                <th className="border border-slate-600 px-2 py-2 w-10">№</th>
                {COLUMNS.map((col) => {
                  const hasFilter = colFilters.get(col.key)?.size;
                  return (
                    <th key={String(col.key)} className="border border-slate-600 px-2 py-2 text-left relative"
                      style={{ width: col.width, minWidth: col.width }}>
                      <div className="flex items-center gap-1">
                        <span className="font-semibold leading-tight">{col.title}</span>
                        {col.key !== 'oscillograms' && (
                          <button className={`ml-auto shrink-0 ${hasFilter ? 'text-amber-300' : 'text-slate-300 hover:text-white'}`}
                            onClick={() => setOpenFilterCol(openFilterCol === col.key ? null : col.key)}
                            title="Фильтр по столбцу">
                            <Filter size={13} />
                          </button>
                        )}
                      </div>
                      {openFilterCol === col.key && (
                        <ColumnFilterPopover
                          colKey={col.key} title={col.title} events={events}
                          selected={colFilters.get(col.key) ?? new Set()}
                          onApply={(vals) => {
                            setColFilters((prev) => {
                              const m = new Map(prev);
                              if (vals.size === 0) m.delete(col.key); else m.set(col.key, vals);
                              return m;
                            });
                            setOpenFilterCol(null);
                          }}
                          onClose={() => setOpenFilterCol(null)}
                        />
                      )}
                    </th>
                  );
                })}
                <th className="border border-slate-600 px-2 py-2 w-20">Действия</th>
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={COLUMNS.length + 2} className="text-center py-10 text-slate-400">
                    {events.length === 0
                      ? 'Нет событий. Нажмите «Добавить событие» или «Импорт событий».'
                      : 'По текущим фильтрам событий не найдено.'}
                  </td>
                </tr>
              )}
              {filtered.map((e, i) => {
                const incomplete = isIncomplete(e);
                return (
                  <tr key={e.id}
                    className={e.refusal ? 'bg-red-600 text-white' : i % 2 ? 'bg-slate-50' : 'bg-white'}
                    onMouseLeave={() => hoveredOsc?.evId === e.id && setHoveredOsc(null)}>
                    <td className={`border px-2 py-1 text-center align-top ${e.refusal ? 'border-red-500' : 'border-slate-200'}`}>{i + 1}</td>
                    {COLUMNS.map((col) => {
                      if (col.key === 'oscillograms') {
                        return (
                          <td key="osc" className={`border px-2 py-1 align-top ${e.refusal ? 'border-red-500' : 'border-slate-200'}`}
                            onMouseEnter={(ev) => e.oscillograms.length > 0 && setHoveredOsc({ evId: e.id, x: ev.clientX, y: ev.clientY })}>
                            {e.oscillograms.length > 0 ? (
                              <span className={`inline-flex items-center gap-1 cursor-help ${e.refusal ? 'text-white' : 'text-blue-700'}`}>
                                <FileText size={14} /> {e.oscillograms.length} шт.
                              </span>
                            ) : (
                              <span className={e.refusal ? 'text-red-200' : 'text-slate-300'}>—</span>
                            )}
                          </td>
                        );
                      }
                      const val = String((e as any)[col.key] ?? '');
                      const empty = val.trim() === '';
                      return (
                        <td key={String(col.key)}
                          className={`border px-2 py-1 align-top whitespace-pre-wrap break-words ${e.refusal ? 'border-red-500' : 'border-slate-200'}`}>
                          {empty ? (
                            <span className={e.refusal ? 'text-red-200 italic' : 'text-slate-300 italic'}>пусто</span>
                          ) : col.key === 'voltage' ? `${val} кВ` : val}
                        </td>
                      );
                    })}
                    <td className={`border px-1 py-1 text-center whitespace-nowrap align-top ${e.refusal ? 'border-red-500' : 'border-slate-200'}`}>
                      <button className="text-blue-600 hover:text-blue-800 px-1" title="Редактировать"
                        onClick={() => { setEditing(e); setShowForm(true); }}>✎</button>
                      <button className="text-red-500 hover:text-red-700 px-1" title="Удалить"
                        onClick={() => deleteEvent(e.id)}>🗑</button>
                      {incomplete && !e.refusal && (
                        <span title="Событие недооформлено" className="text-amber-500 px-0.5">◔</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        <div className="text-xs text-slate-500 mt-2">
          Показано: {filtered.length} из {events.length}. Красным цветом выделены события с отказом. ◔ — недооформленное событие (есть пустые ячейки).
        </div>
      </main>

      {/* Тултип с осциллограммами при наведении */}
      {hoveredOsc && hoveredEvent && hoveredEvent.oscillograms.length > 0 && (
        <div className="fixed z-40 bg-white border border-slate-300 rounded-lg shadow-xl p-3 w-80 pointer-events-auto"
          style={{
            left: Math.min(hoveredOsc.x + 12, window.innerWidth - 340),
            top: Math.min(hoveredOsc.y + 12, window.innerHeight - 320),
          }}
          onMouseLeave={() => setHoveredOsc(null)}>
          <div className="text-xs font-bold mb-2 text-slate-600">Осциллограммы: {hoveredEvent.line || 'без линии'}</div>
          <div className="space-y-2 max-h-72 overflow-y-auto">
            {hoveredEvent.oscillograms.map((o) => (
              <div key={o.id} className="border rounded p-1 cursor-pointer hover:bg-slate-50" onClick={() => setLightbox(o)}>
                <div className="text-xs truncate mb-1">{o.name}</div>
                {o.type.startsWith('image/') ? (
                  <img src={o.dataUrl} alt={o.name} className="w-full max-h-32 object-contain bg-slate-50 rounded" />
                ) : (
                  <div className="text-xs text-slate-500 flex items-center gap-1"><FileText size={14} /> {o.type || 'файл'} — нажмите для открытия</div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Лайтбокс просмотра осциллограммы */}
      {lightbox && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center" onClick={() => setLightbox(null)}>
          <div className="max-w-[90vw] max-h-[90vh] flex flex-col" onClick={(e) => e.stopPropagation()}>
            <div className="text-white text-sm mb-2 flex items-center gap-3">
              <span className="truncate">{lightbox.name}</span>
              <a href={lightbox.dataUrl} download={lightbox.name}
                className="text-blue-300 underline shrink-0">Скачать</a>
              <button className="ml-auto text-white hover:text-red-300" onClick={() => setLightbox(null)}><X size={20} /></button>
            </div>
            {lightbox.type.startsWith('image/') ? (
              <img src={lightbox.dataUrl} alt={lightbox.name} className="max-w-[90vw] max-h-[82vh] object-contain rounded bg-white" />
            ) : lightbox.type === 'application/pdf' ? (
              <iframe src={lightbox.dataUrl} title={lightbox.name} className="w-[80vw] h-[80vh] bg-white rounded" />
            ) : (
              <div className="bg-white p-6 rounded text-sm">Предпросмотр недоступен. <a className="text-blue-600 underline" href={lightbox.dataUrl} download={lightbox.name}>Скачать файл</a></div>
            )}
          </div>
        </div>
      )}

      {/* Модальные окна */}
      {showForm && <EventForm initial={editing} onSave={handleSaveEvent} onClose={() => { setShowForm(false); setEditing(null); }} />}

      {importSheets && <ImportModal sheets={importSheets} onConfirm={confirmImport} onClose={() => setImportSheets(null)} />}

      {confirmClear && (
        <ConfirmModal title="Вы уверены, что хотите очистить таблицу?"
          onClose={() => setConfirmClear(false)}
          buttons={[
            { label: 'Да', danger: true, onClick: () => { setEvents([]); setConfirmClear(false); showToast('Таблица очищена (не забудьте «Сохранить»)'); } },
            { label: 'Нет', onClick: () => setConfirmClear(false) },
          ]} />
      )}

      {confirmExit && (
        <ConfirmModal title={dirty ? 'В таблице есть несохраненные изменения. Выйти?' : 'Выйти из программы?'}
          onClose={() => setConfirmExit(false)}
          buttons={[
            { label: 'Сохранить и выйти', onClick: () => { save(); setConfirmExit(false); exitWithoutSave(); } },
            { label: 'Выйти без сохранения', danger: true, onClick: () => { setConfirmExit(false); exitWithoutSave(); } },
            { label: 'Отмена', onClick: () => setConfirmExit(false) },
          ]} />
      )}

      {toast && (
        <div className="fixed bottom-4 right-4 z-50 bg-slate-800 text-white px-4 py-2 rounded-lg shadow-lg text-sm flex items-center gap-2">
          <AlertTriangle size={15} className="hidden" />{toast}
        </div>
      )}
    </div>
  );
}
